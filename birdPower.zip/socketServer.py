import socket

PORT = 1234
HEADER_SIZE = 10

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((socket.gethostname(), PORT))
s.listen(2)

while True:
    print('waiting for client')
    client_socket, address = s.accept()
    print(f'connection from {address} has been successful!')

    client_socket.send(bytes('t','utf-8'))
    msg = client_socket.recv(30)
    print(msg)
    if msg == '':

        client_socket.close()
